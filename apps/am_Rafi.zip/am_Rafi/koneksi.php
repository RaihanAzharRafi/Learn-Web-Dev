<?php
	$server="localhost";
	$user="root";
	$password="";
	$db="karyawan";

$conn=mysqli_connect($server,$user,$password,$db);




?>